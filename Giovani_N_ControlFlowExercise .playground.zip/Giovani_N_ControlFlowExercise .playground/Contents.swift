import UIKit

var someInts = [Int] ()

someInts.append (8)

print("My Collection List Has \(someInts.count) items")

var Collectionlist: [String]  = ["Funko Pop Figures", "Figures", "Video Games", "Plushies", "Posters", "Starbucks  Cups", "I used to collect Legos", "Books", ]

Collectionlist.sort()

print(Collectionlist)


